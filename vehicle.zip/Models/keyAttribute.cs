﻿using System;

namespace LTIWEBAPPDEMO.Models
{
    internal class keyAttribute : Attribute
    {
    }
}